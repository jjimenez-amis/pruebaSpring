class UserDm{
  constructor(name,email,phone,is,notes,image){
    this.name=name;
    this.email=email;
    this.phone=phone;
    this.is=is;
    this.notes=notes;
    this.image=image;
  }
}
