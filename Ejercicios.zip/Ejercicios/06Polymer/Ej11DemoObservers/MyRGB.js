class MyRGB{
  constructor() {
    this.red = 0;
    this.green = 0;
    this.blue = 0;
  }
}
