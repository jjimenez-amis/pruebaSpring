(
  function(varDocument) {
    // Declaring a Variable
    function declareVariable() {
      if (true) {
        var x = "Declared in a block of code";
      }
      console.log("Value of x: " + x);
    }

    declareVariable();
  }
)(document);
