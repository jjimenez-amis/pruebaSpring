/* Test case #1 - Variables.
 Complete the five variables below, to be one of the following types:
 a of type Undefined
 b of type Null
 c of type Boolean
 d of type String
 e of type Number */

var a;
var b={};
var c=true;
var d="Hola";
var e=7;

console.log("a of type "+typeof a);
console.log("b of type "+typeof b);
console.log("c of type "+typeof c);
console.log("d of type "+typeof d);
console.log("e of type "+typeof e);
