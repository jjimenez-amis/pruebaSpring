// Solution Test case # 1 - Variables
var a;
var b = null;
var c = false;
var d = "This is a String";
var e = 14.8;