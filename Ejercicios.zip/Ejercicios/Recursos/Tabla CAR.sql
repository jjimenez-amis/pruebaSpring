create table "CURSO".CAR
(
    ID INTEGER not null primary key,
    COLOR VARCHAR(255),
    FYEAR INTEGER,
    MODEL VARCHAR(255),
    NAME VARCHAR(255)
)
