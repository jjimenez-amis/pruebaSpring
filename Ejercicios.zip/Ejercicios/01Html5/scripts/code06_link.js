
  console.log("Cargando pagina ...");
  var despedida = document.getElementById('despedida');
  despedida.innerHTML = "Adios";
