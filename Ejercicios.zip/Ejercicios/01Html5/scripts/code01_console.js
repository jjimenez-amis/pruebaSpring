console.info("Inicio de consola");
console.log("Sometimes examples are presented without preview area");
console.log("or instructions.");
console.log("These examples display information in the bottom console pane.");
console.error("Error!!!");
