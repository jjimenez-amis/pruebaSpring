var myfun = function (a,b) {
  return a+b;
}
//myfunc es una variable
var res = myfun(6,10);

console.log(res);
