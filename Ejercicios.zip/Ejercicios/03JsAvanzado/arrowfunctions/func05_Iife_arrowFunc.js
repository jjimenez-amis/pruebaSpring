( (a,b) => {
  let c = a+b;
  console.log('Iife + ArrowFunc :' + c);
  return c;
})(50,100);
