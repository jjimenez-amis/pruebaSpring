var myFun = (a,b) => {
  console.log(a+b);
  return a+b;
};
var res = myFun(21,30);

console.log('Arrow Function: ' + res);
