function sumar(a,b) {
  return a+b;
}

var res = sumar(5,4);

console.log(res);
