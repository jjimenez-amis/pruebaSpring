const avengers = {
 name: 'Thor',
 activity: 'Conquistar chicas'
}

for (property in avengers) {
 console.log(property);
}
