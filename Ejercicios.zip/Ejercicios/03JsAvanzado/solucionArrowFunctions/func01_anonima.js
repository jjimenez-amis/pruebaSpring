let varFun = function(a,b) {
 return a+b;
}

var res = varFun(50,4);

console.log("Inicio");
console.log(res);
console.log("Fin");
