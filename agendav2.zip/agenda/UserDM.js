class UserDm{
  constructor(name,email,phone,is,notes,image){
    this.name=name;
    this.email=email;
    this.phone=phone;
    this.is=is;
    this.notes=notes;
    this.image=image;
  }

  addUser(user){
    let listUsers=[];
    listUsers = JSON.parse(window.localStorage.getItem('users'));
    if(listUsers==null){
      let listUser=[];
      listUser.push(user);
      window.localStorage.setItem('users',JSON.stringify(listUser))
    }else{
      listUsers.push(user);
      window.localStorage.setItem('users',JSON.stringify(listUsers));
    }

  }

  getAll(){
    return window.localStorage.getItem('users');
  }

  update(user){
    
  }
}
